<?php
// $host = 'localhost';
// $user = 'root';
// $pass = '';
// $data = 'petcare';

$host = '10.0.14.117';
$user = 'usera2';
$pass = 'passa2';
$data = 'rpetcare';

$conn = mysqli_connect($host, $user, $pass, $data);
?>